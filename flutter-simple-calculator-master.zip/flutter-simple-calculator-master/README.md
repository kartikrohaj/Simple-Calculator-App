# A simple calculator

A simple calculator app made with Flutter

<img src="./screenshot.png" width="250">
